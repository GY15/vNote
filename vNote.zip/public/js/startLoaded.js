/**
 * Created by Byron Dong on 2017/5/17.
 */
$(document).ready(function () {
    $("body").addClass('loaded');
});
