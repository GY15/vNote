<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title>vNote</title>

    <!-- Bootstrap -->
    <link href="<?php echo e(URL::asset('/')); ?>css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo e(URL::asset('/')); ?>css/manager.css" rel="stylesheet">
    <link href="<?php echo e(URL::asset('/')); ?>css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo e(URL::asset('/')); ?>css/button.css" rel="stylesheet">
</head>
<body>
<header>

    <div class="banner-holder">
        <div class="banner-image-holder" style="z-index: 1">
            <div role="banner" id="fh5co-header" style=" background-position: 0px -170.2px;"
                 data-stellar-background-ratio="0.5">
                <img alt="Background" src="<?php echo e(URL::asset('/')); ?>img/home.jpg" >
                <div class="fh5co-overlay"></div>
            </div>
        </div>
        <!--<div class="jumbotron banner-desc col-md-4 col-md-offset-1" style="z-index: 10;background: transparent;margin-top: 100px">-->
        <!--<div class="container text-center">-->
        <!--<h1 style="color: lightgreen;font-size: 40px">开启您的私人笔记</h1>-->
        <!--</div>-->
        <!--</div>-->
        <div class="jumbotron banner-desc col-md-6 col-md-offset-5">
            <div class="container text-center">
                <div class="userBlock">
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>     <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>     <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>     <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>     <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>     <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>     <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>     <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>     <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                    <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>     <div class="row user">
                        <div class="email col-md-7">你的第一本笔记</div>
                        <div class="col-md-1">
                            <button class="edit button button-royal button-circle button-tiny" style=""><i
                                        class="icon-edit"></i></button>
                        </div>
                        <div class="col-md-1">
                            <button class="delete button button-caution button-circle button-tiny" style=""><i
                                        class="icon-remove "></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo e(URL::asset('/')); ?>js/jquery-3.2.1.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo e(URL::asset('/')); ?>js/bootstrap.js"></script>
<!--<script src="../js/global.js"></script>-->
<script src="<?php echo e(URL::asset('/')); ?>js/icheck.js"></script>

<script type="text/javascript">
    $('.loginBt').click(function () {
        $('.loginPanel').slideDown();
        $('.registerPanel').slideUp("fast");
    });
    $('.regBt').click(function () {
        $('.loginPanel').slideUp();
        $('.registerPanel').slideDown("fast");
    });
    $('.remember').iCheck({
        checkboxClass: 'icheckbox_flat-green',
        radioClass:  'iradio_flat-green'
    });
    $(document).ready(function(){
        var a =<?php echo e(isset($type) ? $type : "false"); ?> ;
        if (!a) {
            $(".loginPanel").show();
        }else{
            if (a == 1) {
                $(".registerPanel").show();
            } else {
                $(".loginPanel").show();
            }
        }
        setTimeout(function () {$('.errorMessage').hide()}, 2000);
    });
</script>

</body>
</html>